from __future__ import annotations

import json
import re
from pathlib import Path


WORKSPACE = Path("/workspace/scratch/0299d32e143a")
if Path(__file__).resolve().parent.name == "tests":
    ROOT = Path(__file__).resolve().parents[1]
else:
    ROOT = WORKSPACE / "outputs/ux_ui_phase6/c4_planning"
PHASE6 = WORKSPACE / "outputs/ux_ui_phase6"


def load_json(path: Path):
    return json.loads(path.read_text())


manifest = load_json(ROOT / "contract-manifest.json")
scenarios = load_json(ROOT / "scenario-traceability.json")
components = load_json(ROOT / "component-traceability.json")
backlog = load_json(ROOT / "implementation-backlog.json")
dependencies = load_json(ROOT / "dependency-map.json")
ci_gates = load_json(ROOT / "ci-release-gates.json")
authorization = load_json(ROOT / "implementation-authorization.json")
acceptance_text = (PHASE6 / "Mythic_RPG_C4_Traceability_Backlog_and_Implementation_Gate_v0.1.md").read_text()

assert manifest["checkpoint"] == "C4"
assert manifest["status"] == "approved"
assert manifest["approved_on"] == "2026-08-23"
assert manifest["implementation_authorized"] is False
assert all(item["status"] == "approved" for item in manifest["approved_dependencies"])
assert [item["checkpoint"] for item in manifest["approved_dependencies"]] == ["C1", "C2", "C3"]
assert manifest["product_decisions"]["world_time"] == "Ledger Time"
assert manifest["product_decisions"]["primary_workspace"] == "Adaptive Living World Stage"
assert manifest["product_decisions"]["primary_device"] == "Desktop browser first"
assert "not chatbot skin" in manifest["product_decisions"]["experience_character"]
assert "Figma-free" in manifest["product_decisions"]["high_fidelity_workflow"]

c1 = load_json(PHASE6 / "c1_contracts/validation_report.json")
c2 = load_json(PHASE6 / "c2_contracts/validation_report.json")
c3 = load_json(PHASE6 / "c3_contracts/validation_report.json")
expected_contract_counts = {"C1": 24, "C2": 43, "C3": 60}
for checkpoint, report in [("C1", c1), ("C2", c2), ("C3", c3)]:
    assert report["fixture_count"] == expected_contract_counts[checkpoint]
    assert report["passed_count"] == report["fixture_count"]
    assert report["failed_count"] == 0

c3_manifest = load_json(PHASE6 / "c3_contracts/contract-manifest.json")
assert c3_manifest["status"] == "approved"
assert c3_manifest["implementation_authorized"] is False

expected_scenarios = {f"SCN-{number:02d}" for number in range(1, 18)}
expected_components = {f"CMP-{number:02d}" for number in range(1, 41)}
assert {item["scenario_id"] for item in scenarios} == expected_scenarios
assert {item["component_id"] for item in components} == expected_components
assert len(scenarios) == 17
assert len(components) == 40

scenario_fields = {
    "scenario_id", "scenario", "contracts", "fixtures_tests", "engine_prerequisites",
    "frontend_slice", "release_validation", "trace_status", "implementation_status",
}
for item in scenarios:
    assert scenario_fields <= item.keys()
    assert all(item[field] for field in scenario_fields)
    assert item["trace_status"] == "Contract trace complete"
    assert item["implementation_status"].startswith("Pending")
    assert all(re.match(r"^(COMMON|RM|CMD|EVF|API|ASYNC|GEN|C2-|C3-)", contract) for contract in item["contracts"])

component_fields = {
    "component_id", "name", "contracts", "primary_payloads", "authority_owner",
    "frontend_owner", "fixtures_tests", "accessibility_semantics", "implementation_slice",
    "trace_status", "implementation_status",
}
for item in components:
    assert component_fields <= item.keys()
    assert all(item[field] for field in component_fields)
    assert item["trace_status"] == "Contract trace complete"
    assert item["implementation_status"].startswith("Pending")

backlog_fields = {
    "sequence", "item_id", "phase", "capability", "player_outcome", "contracts",
    "authority_owner", "implementation_owner", "dependencies", "state_version_assumptions",
    "knowledge_permission_boundary", "success_branch", "exception_branches", "ui_states",
    "accessibility_semantics", "analytics_category", "fixtures_tests", "requirements",
    "scenarios", "components", "definition_of_done", "authorization_status",
}
assert [item["sequence"] for item in backlog] == list(range(1, len(backlog) + 1))
assert len({item["item_id"] for item in backlog}) == len(backlog) == 24
for item in backlog:
    assert backlog_fields <= item.keys()
    assert all(item[field] not in (None, "", []) for field in backlog_fields - {"dependencies"})
    assert item["authorization_status"] == "Planned; production implementation closed"
    assert set(item["ui_states"]) == {"loading", "empty", "stale", "conflict", "recovery"}

ids = [item["item_id"] for item in backlog]
assert ids[:6] == [f"PRE-{number:02d}" for number in range(1, 7)]
assert ids[6:10] == [f"UI-{number:02d}" for number in range(1, 5)]
assert "VS-01" in ids and "VS-03" in ids and ids.index("VS-03") < ids.index("VS-04")
assert backlog[ids.index("VS-03")]["capability"].startswith("Intent → interpretation")
assert ids[-1] == "REL-01"

assert len(dependencies) == len(backlog)
assert {item["node_id"] for item in dependencies} == set(ids)
assert all(item["unlock_condition"] for item in dependencies)

assert len(ci_gates) == 15
assert {item["gate_id"] for item in ci_gates} == {f"CI-{number:02d}" for number in range(1, 16)}
for item in ci_gates:
    for field in ["name", "evidence", "owner", "stage", "blocks_when", "status"]:
        assert item[field]
    assert item["status"] == "Defined; pending implementation"

assert authorization["decision"] == "CLOSED"
assert "withhold production implementation" in authorization["recommendation"].lower()
assert any(item["gate"] == "Figma-free code-native component library" and item["status"] == "OPEN" for item in authorization["gates"])
assert any(item["gate"] == "C3 async/accessibility/media contracts" and item["status"] == "PASS" for item in authorization["gates"])
assert "Figma-free" in acceptance_text
assert "Implementation authorization:** **CLOSED" in acceptance_text
assert "SCN-17" in acceptance_text and "CMP-40" in acceptance_text and "CI-15" in acceptance_text

report = {
    "checkpoint": "C4",
    "status": "approved",
    "approved_dependency_fixture_expectations": sum(expected_contract_counts.values()),
    "scenario_trace_count": len(scenarios),
    "component_trace_count": len(components),
    "backlog_item_count": len(backlog),
    "dependency_node_count": len(dependencies),
    "ci_release_gate_count": len(ci_gates),
    "implementation_authorization": authorization["decision"],
    "failed_gate_count": 0,
}
(ROOT / "validation_report.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
