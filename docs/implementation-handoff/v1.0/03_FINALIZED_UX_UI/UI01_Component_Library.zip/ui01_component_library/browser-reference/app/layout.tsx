import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Mythic RPG UI-01 Component Library",
  description:
    "The approved, Figma-free component specification for the Mythic Superhero RPG desktop browser experience.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
