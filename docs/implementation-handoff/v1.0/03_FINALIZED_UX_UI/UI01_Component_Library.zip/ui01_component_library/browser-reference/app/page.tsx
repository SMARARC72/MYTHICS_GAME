"use client";

import { useMemo, useState } from "react";

type Family = "World shell" | "Core loop" | "Systems" | "Accessibility";

type ComponentSpec = {
  id: string;
  name: string;
  family: Family;
  purpose: string;
  props: string[];
  states: string[];
  responsive: string;
  a11y: string;
};

const specs: ComponentSpec[] = [
  { id: "CMP-01", name: "World Strip", family: "World shell", purpose: "Keeps Ledger Time, viewpoint, weather, pressure and world status continuously legible.", props: ["ledgerTime", "viewpoint", "weather", "pressure", "status"], states: ["current", "changed", "urgent", "offline"], responsive: "Sticky full-width strip; compact mode wraps facts into two labeled rows.", a11y: "A named world-status region; updates announce once without taking focus." },
  { id: "CMP-02", name: "Campaign Rail", family: "World shell", purpose: "Provides six stable destinations while keeping the Stage as the gravitational center.", props: ["destinations", "activeId", "attention", "collapsed"], states: ["default", "active", "attention", "collapsed"], responsive: "Persistent desktop rail; below 980px becomes a labeled horizontal destination bar.", a11y: "Primary navigation with current-page state and text labels at every density." },
  { id: "CMP-03", name: "Active Surface Header", family: "World shell", purpose: "Names the current surface, viewpoint, knowledge class and fixture boundary.", props: ["title", "viewpoint", "knowledgeClass", "fixture"], states: ["ready", "loading", "stale", "conflict"], responsive: "Title and boundary remain visible; metadata moves to a second line when narrow.", a11y: "Level-one heading followed by a concise status description." },
  { id: "CMP-04", name: "Context Lens", family: "World shell", purpose: "Lets players inspect an entity without leaving the living world.", props: ["entity", "facts", "evidence", "actions"], states: ["closed", "open", "loading", "unavailable"], responsive: "Desktop right rail; compact layouts use a non-modal disclosure below the Stage.", a11y: "Named complementary region; disclosure preserves focus and reading position." },
  { id: "CMP-05", name: "Intent Dock", family: "Core loop", purpose: "Captures free goal and method as game control, never as a chat composer.", props: ["goal", "method", "objects", "draftState"], states: ["empty", "drafting", "interpreted", "blocked"], responsive: "Anchored to Stage on desktop; flows after scene content on compact screens.", a11y: "Explicit Goal and Method labels, draft status and keyboard-accessible submit path." },
  { id: "CMP-06", name: "Chronicle Ribbon", family: "World shell", purpose: "Shows recent canon and provenance without turning play into a transcript.", props: ["entries", "provenance", "expanded", "unread"], states: ["empty", "recent", "expanded", "stale"], responsive: "Single-line ribbon expands in place; never becomes the primary column.", a11y: "Ordered record region with meaningful timestamps and an unread count." },
  { id: "CMP-07", name: "Attention Notice", family: "World shell", purpose: "Calls out due, changed or unavailable state using label, shape and color together.", props: ["kind", "title", "detail", "action"], states: ["due", "changed", "unavailable", "resolved"], responsive: "Inline or stacked banner; action remains adjacent to its explanation.", a11y: "Status or alert role is chosen by urgency; icon is never the only cue." },
  { id: "CMP-08", name: "Draft Preservation Bar", family: "World shell", purpose: "Confirms uncommitted work survives navigation, interruption and reconnect.", props: ["draftName", "savedAt", "syncState", "restoreAction"], states: ["saved", "saving", "offline", "restored"], responsive: "Pinned beneath the relevant surface header; shortens copy, not capability.", a11y: "Polite live status; restore action has an explicit target name." },
  { id: "CMP-09", name: "Scene Frame", family: "Core loop", purpose: "Presents geography, actors, objects and continuity as an explorable scene.", props: ["location", "actors", "objects", "continuity"], states: ["loading", "ready", "changed", "recovery"], responsive: "Wide atmospheric frame becomes a vertical fact stack without hiding objects.", a11y: "Scene heading and structured lists precede any decorative treatment." },
  { id: "CMP-10", name: "Exact Speech Block", family: "Core loop", purpose: "Binds exact dialogue to its speaker without rewriting or summarizing it.", props: ["speaker", "speech", "tone", "source"], states: ["speaking", "heard", "translated", "unavailable"], responsive: "Readable measure is capped; speaker and quote stay inseparable.", a11y: "Block quote with programmatic speaker attribution; punctuation is preserved." },
  { id: "CMP-11", name: "Meaningful Marker", family: "Core loop", purpose: "Makes a scene fact inspectable without presenting a command menu.", props: ["label", "kind", "confidence", "target"], states: ["known", "uncertain", "changed", "selected"], responsive: "Markers become labeled chips in reading order when spatial placement is unavailable.", a11y: "Button name states the entity and meaning; confidence is spoken as text." },
  { id: "CMP-12", name: "Contextual Possibility", family: "Core loop", purpose: "Surfaces relevant affordances without implying a complete legal-action list.", props: ["possibility", "reason", "scope", "apply"], states: ["suggested", "inspected", "applied", "expired"], responsive: "Two-column suggestion row becomes a scroll-free vertical list.", a11y: "Introduced as examples, not exhaustive choices; each action describes its effect." },
  { id: "CMP-13", name: "Interpreted Action Packet", family: "Core loop", purpose: "Shows goal, method, objects and assumptions in a correctable packet.", props: ["goal", "method", "objects", "assumptions", "edit"], states: ["interpreting", "ready", "correcting", "conflict"], responsive: "Four labeled fields stay visible; controls stack beneath their field.", a11y: "Definition-list structure; changed assumptions receive a text cue and focusable edit." },
  { id: "CMP-14", name: "Knowable Forecast", family: "Core loop", purpose: "Previews only accessible time, cost, exposure and uncertainty.", props: ["time", "cost", "exposure", "uncertainty", "basis"], states: ["available", "partial", "uncertain", "unavailable"], responsive: "Four facts wrap as equal cards; unknown values are labeled, never blank.", a11y: "Forecast has a heading, source note and explicit unknown/estimated language." },
  { id: "CMP-15", name: "Adaptive Commit", family: "Core loop", purpose: "Matches commitment depth to the material consequence of an action.", props: ["level", "summary", "consequences", "confirm"], states: ["light", "material", "irreversible", "blocked"], responsive: "Confirmation expands in place; irreversible copy remains visible beside the action.", a11y: "Button names the commitment; destructive or irreversible consequences are announced first." },
  { id: "CMP-16", name: "Resolution Beat", family: "Core loop", purpose: "Connects cause and result in a brief, skippable, motion-safe beat.", props: ["steps", "duration", "skip", "reducedMotion"], states: ["queued", "playing", "skipped", "complete"], responsive: "Uses the same content sequence at all sizes; motion is never required for meaning.", a11y: "Pause/skip controls and a textual final state; reduced motion removes transforms." },
  { id: "CMP-17", name: "Outcome Receipt", family: "Core loop", purpose: "Explains an authoritative result with depth proportional to what changed.", props: ["summary", "causes", "changes", "receiptId"], states: ["success", "mixed", "failure", "duplicate"], responsive: "Summary remains first; causal details collapse under a labeled disclosure.", a11y: "Status heading, structured change list and stable receipt identifier." },
  { id: "CMP-18", name: "Decision Window", family: "Core loop", purpose: "Names urgent closure time, cause and available responses without surprise.", props: ["closesAt", "cause", "choices", "default"], states: ["open", "due", "closing", "closed"], responsive: "Time and cause stay above choices; no horizontal countdown dependency.", a11y: "Time remaining is announced at meaningful thresholds, not every second." },
  { id: "CMP-19", name: "Interrupt Queue", family: "Core loop", purpose: "Lets danger pause an action while preserving draft and canonical state.", props: ["interrupts", "draft", "resume", "priority"], states: ["clear", "paused", "resolving", "resumed"], responsive: "Appears between scene and intent; never overlays or erases the draft.", a11y: "Urgent alert followed by focusable choices; resume returns focus to the preserved draft." },
  { id: "CMP-20", name: "Tactical Emphasis Strip", family: "Core loop", purpose: "Intensifies combat information without replacing the same geography.", props: ["turn", "range", "threats", "cover"], states: ["inactive", "active", "reaction", "resolved"], responsive: "Wraps tactical facts under the scene header; spatial equivalents become text rows.", a11y: "Tactical state uses headings and ordered turn information, not position or color alone." },
  { id: "CMP-21", name: "BP Ledger", family: "Systems", purpose: "Makes Build Point source, spend, prerequisites and unspent balance auditable.", props: ["sources", "spends", "prerequisites", "balance"], states: ["balanced", "unspent", "invalid", "conflict"], responsive: "Desktop table becomes labeled ledger rows with totals retained.", a11y: "Captioned table or equivalent row semantics; errors reference the exact spend." },
  { id: "CMP-22", name: "Condition / Wound Card", family: "Systems", purpose: "Separates fiction, severity, family, penalty and treatment.", props: ["fiction", "severity", "family", "penalty", "treatment"], states: ["active", "stabilized", "treated", "worsened"], responsive: "Severity and family remain beside title; treatment flows below effects.", a11y: "Severity is written as text and not encoded solely by red or icon shape." },
  { id: "CMP-23", name: "Relationship Card", family: "Systems", purpose: "Shows observable evidence and boundaries instead of obedience meters.", props: ["person", "evidence", "boundaries", "openQuestions"], states: ["known", "changed", "strained", "unknown"], responsive: "Evidence timeline condenses to recent evidence plus an expand control.", a11y: "No unlabeled numeric sentiment; evidence and boundary statements use plain language." },
  { id: "CMP-24", name: "Relic Bond Card", family: "Systems", purpose: "Keeps custody, Claim, Attunement, Bond and agency distinct.", props: ["relic", "custody", "claim", "attunement", "bond"], states: ["unclaimed", "claimed", "attuned", "contested"], responsive: "Five relationship facts become a labeled vertical sequence.", a11y: "Terms are expanded through definitions; agency state is stated separately." },
  { id: "CMP-25", name: "Custody and Access Row", family: "Systems", purpose: "Separates owner, holder, location, authority and availability.", props: ["owner", "holder", "location", "authority", "availability"], states: ["available", "restricted", "disputed", "unknown"], responsive: "Five columns collapse into a key/value row without semantic loss.", a11y: "Every value retains its label; unknown is announced explicitly." },
  { id: "CMP-26", name: "Item Comparison", family: "Systems", purpose: "Compares task-relative tradeoffs without inventing a universal score.", props: ["items", "task", "tradeoffs", "evidence"], states: ["ready", "partial", "changed", "unavailable"], responsive: "Side-by-side comparison becomes item-first sections with repeated criteria.", a11y: "Criteria and item headers are associated; preferred is not color-only." },
  { id: "CMP-27", name: "Craft / Repair Plan", family: "Systems", purpose: "Persists intervals, materials, facility and checkpoints as a durable plan.", props: ["intervals", "materials", "facility", "checkpoints"], states: ["draft", "ready", "inProgress", "blocked"], responsive: "Timeline becomes an ordered checklist with the same checkpoint data.", a11y: "Progress has text equivalents; missing prerequisites link to their field." },
  { id: "CMP-28", name: "Route / Journey Card", family: "Systems", purpose: "Shows known legs, roles, supplies, stops and uncertainty.", props: ["legs", "roles", "supplies", "stops", "uncertainty"], states: ["planned", "underway", "interrupted", "arrived"], responsive: "Map-adjacent route becomes a numbered leg list on compact layouts.", a11y: "Ordered legs and role assignments remain available without a visual map." },
  { id: "CMP-29", name: "Knowledge-Safe Map", family: "Systems", purpose: "Displays believed position and confidence while omitting hidden coordinates.", props: ["beliefs", "confidence", "knownPlaces", "viewpoint"], states: ["known", "estimated", "stale", "unavailable"], responsive: "Graphical map pairs with a complete text place/route list.", a11y: "Equivalent structured geography; confidence and source are available per place." },
  { id: "CMP-30", name: "Evidence Claim", family: "Systems", purpose: "Tracks source, custody, confidence and contradictions for a claim.", props: ["claim", "source", "custody", "confidence", "contradictions"], states: ["supported", "contested", "contradicted", "unverified"], responsive: "Claim stays first; provenance fields wrap beneath it.", a11y: "Confidence uses words, contradictions are a named list, and source links are descriptive." },
  { id: "CMP-31", name: "Front Pressure Card", family: "Systems", purpose: "Shows evidence-backed qualitative pressure without revealing a secret clock.", props: ["front", "pressure", "evidence", "change"], states: ["quiet", "building", "immediate", "changed"], responsive: "Pressure and evidence remain paired in a single-column card.", a11y: "Qualitative label and evidence text replace unlabeled meters." },
  { id: "CMP-32", name: "Legal Process Card", family: "Systems", purpose: "Separates evidence, jurisdiction, authority and guilt.", props: ["matter", "evidence", "jurisdiction", "authority", "finding"], states: ["inquiry", "hearing", "decision", "appeal"], responsive: "Process stages form a vertical ordered sequence below 720px.", a11y: "Current process stage is announced; guilt is never inferred from custody or charge." },
  { id: "CMP-33", name: "Comic Job Card", family: "Systems", purpose: "Shows honest durable media stages while gameplay continues independently.", props: ["job", "stage", "provenance", "retry"], states: ["queued", "drafting", "review", "published"], responsive: "Job facts stack; gameplay status remains visibly independent.", a11y: "Stage names are textual, updates are polite, and failure offers a specific retry." },
  { id: "CMP-34", name: "Comic Reader Controls", family: "Systems", purpose: "Makes edition, spoiler ceiling and access modes explicit.", props: ["edition", "ceiling", "readingMode", "navigation"], states: ["ready", "loading", "restricted", "offline"], responsive: "Controls become two labeled rows; reading order and page navigation remain intact.", a11y: "Page/strip modes, edition and spoiler ceiling are programmatically named." },
  { id: "CMP-35", name: "Visible Focus", family: "Accessibility", purpose: "Provides a durable high-contrast focus indicator with clear offset.", props: ["color", "width", "offset", "forcedColors"], states: ["rest", "focusVisible", "forcedColors", "invalid"], responsive: "Same minimum indicator at every size and zoom level.", a11y: "At least a 2px contrasting outline with offset; never suppressed without replacement." },
  { id: "CMP-36", name: "Semantic Regions", family: "Accessibility", purpose: "Establishes stable world, navigation, Stage, record and notice landmarks.", props: ["world", "navigation", "stage", "record", "notices"], states: ["default", "compact", "loading", "updated"], responsive: "Visual movement does not change landmark identity or reading order.", a11y: "Unique labels for repeated regions and one primary main landmark." },
  { id: "CMP-37", name: "Noncolor State Cue", family: "Accessibility", purpose: "Carries meaning through labels, shapes and structure in addition to color.", props: ["label", "shape", "pattern", "tone"], states: ["info", "success", "warning", "danger"], responsive: "Cue label remains visible; icons never shrink below the target minimum.", a11y: "State word is exposed to assistive tech; decorative color is ignored." },
  { id: "CMP-38", name: "Live-Region Message", family: "Accessibility", purpose: "Announces material world or blocking change without stealing focus.", props: ["message", "urgency", "dedupeKey", "scope"], states: ["idle", "polite", "assertive", "deduped"], responsive: "Visually placed near source while remaining one stable live region.", a11y: "Polite by default, assertive only for blocking danger; duplicate announcements collapse." },
  { id: "CMP-39", name: "Alternate Input Tray", family: "Accessibility", purpose: "Offers core intent control without precision pointer use or free typing.", props: ["goals", "methods", "selection", "submit"], states: ["closed", "open", "selected", "submitted"], responsive: "Full-width button grid becomes a vertical list with unchanged capability.", a11y: "Roving or ordinary tab order is documented; selection and submission are distinct." },
  { id: "CMP-40", name: "Motion Substitute", family: "Accessibility", purpose: "Replaces nonessential animation with a text sequence or immediate final state.", props: ["sequence", "finalState", "preference", "duration"], states: ["animated", "reduced", "skipped", "complete"], responsive: "Substitute content is identical across layout sizes.", a11y: "Respects reduced-motion preference and never hides meaning behind motion." },
];

const familyOrder: ("All" | Family)[] = ["All", "World shell", "Core loop", "Systems", "Accessibility"];
const familyLabels: Record<Family, string> = { "World shell": "Orientation", "Core loop": "Play loop", Systems: "World systems", Accessibility: "Access layer" };

function sampleCopy(spec: ComponentSpec) {
  const samples: Record<Family, [string, string, string]> = {
    "World shell": ["Ledger 47 · 18:40", "Glass Harbor · Rain", "Pressure changed"],
    "Core loop": ["Reach the archive", "Through the flood tunnels", "Exposure: uncertain"],
    Systems: ["Evidence-backed", "Custody verified", "State persists"],
    Accessibility: ["Keyboard ready", "Text equivalent", "No focus theft"],
  };
  return samples[spec.family];
}

function ComponentPreview({ spec, state }: { spec: ComponentSpec; state: string }) {
  const [primary, secondary, tertiary] = sampleCopy(spec);
  return (
    <div className={`component-preview family-${spec.family.toLowerCase().replaceAll(" ", "-")} state-${state.toLowerCase().replaceAll(" ", "-")}`}>
      <div className="preview-kicker"><span aria-hidden="true">◆</span> {spec.id} · {state}</div>
      <div className="preview-main"><div><strong>{primary}</strong><span>{secondary}</span></div><span className="state-pill">{tertiary}</span></div>
      <div className="preview-rule"><span style={{ width: `${38 + (Number(spec.id.slice(-2)) % 5) * 11}%` }} /></div>
    </div>
  );
}

export default function Home() {
  const [query, setQuery] = useState("");
  const [family, setFamily] = useState<"All" | Family>("All");
  const [density, setDensity] = useState<"comfortable" | "compact">("comfortable");
  const [contrast, setContrast] = useState(false);
  const [largeText, setLargeText] = useState(false);
  const [reduceMotion, setReduceMotion] = useState(false);
  const [selectedId, setSelectedId] = useState("CMP-05");
  const [demoState, setDemoState] = useState("drafting");
  const [goal, setGoal] = useState("");
  const [method, setMethod] = useState("");
  const [committed, setCommitted] = useState(false);

  const selected = specs.find((item) => item.id === selectedId) ?? specs[4];
  const filtered = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return specs.filter((item) => (family === "All" || item.family === family) && (!normalized || `${item.id} ${item.name} ${item.purpose}`.toLowerCase().includes(normalized)));
  }, [family, query]);

  function chooseSpec(spec: ComponentSpec) {
    setSelectedId(spec.id);
    setDemoState(spec.states[0]);
    document.getElementById("specimen")?.scrollIntoView({ behavior: reduceMotion ? "auto" : "smooth", block: "center" });
  }

  return (
    <div className={`library-app density-${density} ${contrast ? "high-contrast" : ""} ${largeText ? "large-text" : ""} ${reduceMotion ? "reduce-motion" : ""}`}>
      <a className="skip-link" href="#main-content">Skip to component library</a>
      <header className="world-strip" aria-label="World status specimen">
        <div className="brand-lockup"><span className="brand-mark" aria-hidden="true">M</span><div><strong>MYTHIC</strong><span>UI-01 · v0.1</span></div></div>
        <dl className="world-facts"><div><dt>Ledger Time</dt><dd>Day 47 · 18:40</dd></div><div><dt>Viewpoint</dt><dd>Vesper Quill</dd></div><div><dt>Weather</dt><dd>Hard rain · East wind</dd></div><div><dt>Pressure</dt><dd><span className="signal warning">▲ Building</span></dd></div></dl>
        <div className="gate-chip"><span aria-hidden="true">■</span> Production gate closed</div>
      </header>

      <div className="library-shell">
        <aside className="campaign-rail" aria-label="Component library navigation">
          <div className="rail-heading"><span>REFERENCE</span><strong>Component Library</strong></div>
          <nav><a href="#stage" className="active"><span aria-hidden="true">◈</span> Living Stage</a><a href="#catalog"><span aria-hidden="true">▦</span> Components <b>40</b></a><a href="#tokens"><span aria-hidden="true">◐</span> Tokens</a><a href="#states"><span aria-hidden="true">◇</span> State grammar</a><a href="#access"><span aria-hidden="true">◎</span> Accessibility</a></nav>
          <div className="rail-note"><span className="eyebrow">BINDING DECISIONS</span><p>Desktop first</p><p>Adaptive Stage</p><p>Ledger Time</p><p>Figma-free</p></div>
        </aside>

        <main id="main-content">
          <section id="stage" className="stage-section" aria-labelledby="stage-title">
            <header className="surface-header"><div><span className="eyebrow">LIVE SPECIMEN · PLAYER VIEWPOINT</span><h1 id="stage-title">The Archive Below Glass Harbor</h1></div><div className="knowledge-chip"><span>KNOWN</span> Fixture-safe example</div></header>
            <div className="stage-grid">
              <div className="scene-frame">
                <div className="scene-atmosphere" aria-hidden="true"><span /><span /><span /></div>
                <div className="scene-copy"><span className="scene-label">LOWER TRANSIT · EAST VAULT</span><h2>Rainwater threads through the broken skylight.</h2><p>The sealed archive door sits beyond a flooded rail trench. Two maintenance lamps still burn. A figure waits beneath the eastern arch.</p></div>
                <div className="marker-row" aria-label="Meaningful scene markers"><button><span aria-hidden="true">◇</span> Flooded trench <small>Known hazard</small></button><button><span aria-hidden="true">○</span> Waiting figure <small>Identity uncertain</small></button><button><span aria-hidden="true">□</span> Archive seal <small>Recently changed</small></button></div>
              </div>
              <aside className="context-lens" aria-label="Inspected entity"><span className="eyebrow">CONTEXT LENS</span><div className="lens-title"><div className="entity-glyph" aria-hidden="true">AQ</div><div><h3>Archive Seal</h3><p>Municipal ward · modified</p></div></div><dl><div><dt>Observed</dt><dd>Fresh silver scoring</dd></div><div><dt>Confidence</dt><dd>High</dd></div><div><dt>Source</dt><dd>Direct sight</dd></div></dl><button className="text-action">Review evidence <span aria-hidden="true">→</span></button></aside>
            </div>
            <blockquote className="speech-block"><span className="speaker-avatar" aria-hidden="true">N</span><div><cite>Nyra Vale</cite><p>“If you cross the trench, do it quietly. The seal is listening for names.”</p></div><span className="speech-source">Heard directly</span></blockquote>
            <div className="intent-dock">
              <div className="dock-heading"><div><span className="eyebrow">INTENT DOCK</span><h3>What does Vesper try?</h3></div><span className={`draft-status ${goal ? "has-draft" : ""}`}>{goal ? "● Draft preserved" : "○ Awaiting intent"}</span></div>
              <div className="intent-fields"><label><span>Goal</span><input value={goal} onChange={(event) => { setGoal(event.target.value); setCommitted(false); }} placeholder="e.g. Reach the archive unnoticed" /></label><label><span>Method</span><input value={method} onChange={(event) => { setMethod(event.target.value); setCommitted(false); }} placeholder="e.g. Use the maintenance ledge" /></label><button className="interpret-button" onClick={() => goal.trim() && setCommitted(true)} disabled={!goal.trim()}>Interpret intent <span aria-hidden="true">→</span></button></div>
              <div className="possibility-row"><span>Relevant possibilities, not limits:</span><button onClick={() => setMethod("Trace the maintenance ledge above the trench")}>Use the ledge</button><button onClick={() => setMethod("Ask Nyra what the seal listens for")}>Question Nyra</button><button onClick={() => setMethod("Inspect the silver scoring before crossing")}>Study the seal</button></div>
            </div>
            {committed && <div className="interpretation" role="status" aria-live="polite"><div><span className="eyebrow">INTERPRETED ACTION</span><strong>{goal}</strong><p>Method: {method || "Direct approach; method not specified"}</p></div><dl><div><dt>Ledger time</dt><dd>About 8 minutes</dd></div><div><dt>Exposure</dt><dd>Uncertain</dd></div><div><dt>Assumption</dt><dd>East ledge bears weight</dd></div></dl><button onClick={() => setCommitted(false)}>Correct interpretation</button></div>}
          </section>

          <section id="catalog" className="library-section" aria-labelledby="catalog-title">
            <div className="section-heading"><div><span className="eyebrow">CANONICAL INVENTORY</span><h2 id="catalog-title">40 component obligations</h2><p>Presentation may own focus, reversible drafts and composition. Canon remains contract-authoritative.</p></div><span className="count-badge">{filtered.length} shown</span></div>
            <div className="tool-bar" aria-label="Library display controls"><label className="search-field"><span className="sr-only">Search components</span><span aria-hidden="true">⌕</span><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search by ID, name or purpose" /></label><div className="segmented" aria-label="Family filter">{familyOrder.map((item) => <button key={item} onClick={() => setFamily(item)} className={family === item ? "selected" : ""} aria-pressed={family === item}>{item}</button>)}</div></div>
            <div className="component-layout">
              <div className="component-grid">{filtered.map((spec) => <article className={`component-card ${selectedId === spec.id ? "selected-card" : ""}`} key={spec.id}><button className="card-select" onClick={() => chooseSpec(spec)} aria-label={`Inspect ${spec.id} ${spec.name}`}><div className="card-top"><span>{spec.id}</span><em>{familyLabels[spec.family]}</em></div><ComponentPreview spec={spec} state={spec.states[0]} /><h3>{spec.name}</h3><p>{spec.purpose}</p><div className="card-foot"><span>{spec.props.length} props</span><span>{spec.states.length} states</span><strong>Inspect <span aria-hidden="true">→</span></strong></div></button></article>)}</div>
              <aside id="specimen" className="specimen-panel" aria-label="Selected component specification"><div className="specimen-sticky"><div className="specimen-id"><span>{selected.id}</span><em>{selected.family}</em></div><h3>{selected.name}</h3><p>{selected.purpose}</p><ComponentPreview spec={selected} state={demoState} /><fieldset><legend>Interactive state</legend><div className="state-buttons">{selected.states.map((state) => <button key={state} onClick={() => setDemoState(state)} className={demoState === state ? "selected" : ""} aria-pressed={demoState === state}>{state}</button>)}</div></fieldset><div className="spec-block"><h4>Props</h4><div className="code-tags">{selected.props.map((prop) => <code key={prop}>{prop}</code>)}</div></div><div className="spec-block"><h4>Responsive rule</h4><p>{selected.responsive}</p></div><div className="spec-block"><h4>Accessibility semantics</h4><p>{selected.a11y}</p></div><div className="contract-note"><span aria-hidden="true">✓</span><div><strong>Contract-bound</strong><p>No hidden truth, permission or canon mutation may be invented here.</p></div></div></div></aside>
            </div>
          </section>

          <section id="tokens" className="library-section token-section" aria-labelledby="tokens-title">
            <div className="section-heading"><div><span className="eyebrow">FOUNDATION TOKENS</span><h2 id="tokens-title">A world of ink, stormlight and signal</h2><p>Quiet surfaces carry dense information; warm light marks agency, not decoration.</p></div></div>
            <div className="token-grid"><article><h3>Surface</h3><div className="swatches"><span style={{ background: "#080d13" }}><b>Void</b><small>#080D13</small></span><span style={{ background: "#101821" }}><b>Slate</b><small>#101821</small></span><span style={{ background: "#17232d" }}><b>Raised</b><small>#17232D</small></span><span className="light-swatch" style={{ background: "#e7edf0" }}><b>Ink light</b><small>#E7EDF0</small></span></div></article><article><h3>Semantic signal</h3><div className="swatches"><span style={{ background: "#d6a64d" }}><b>Agency</b><small>#D6A64D</small></span><span style={{ background: "#62c6bb" }}><b>Known</b><small>#62C6BB</small></span><span style={{ background: "#e08a5c" }}><b>Pressure</b><small>#E08A5C</small></span><span style={{ background: "#b785d6" }}><b>Uncertain</b><small>#B785D6</small></span></div></article><article className="type-spec"><h3>Typography</h3><p className="display-type">Living worlds deserve clear decisions.</p><p className="body-type">Interface copy favors compact, concrete language. Ledger facts use a measured mono voice; scene prose gets more air.</p><code>LEDGER 47 · 18:40 · VERSION 0.1</code></article><article><h3>Geometry & rhythm</h3><div className="geometry-demo"><span>4</span><span>8</span><span>12</span><span>16</span><span>24</span><span>32</span></div><p>Controls: 40px minimum · Core radius: 6px · Panels: 10px · Focus offset: 3px</p></article></div>
          </section>

          <section id="states" className="library-section" aria-labelledby="states-title">
            <div className="section-heading"><div><span className="eyebrow">SEMANTIC STATE GRAMMAR</span><h2 id="states-title">Meaning survives color, motion and interruption</h2><p>Every state carries a word, structural cue and recovery path.</p></div></div>
            <div className="state-matrix" role="table" aria-label="Semantic state matrix"><div className="matrix-head" role="row"><span role="columnheader">State</span><span role="columnheader">Visible cue</span><span role="columnheader">System promise</span><span role="columnheader">Player path</span></div>{[["Loading", "○ Skeleton + label", "No false completion", "Wait or leave safely"], ["Empty", "◇ Named absence", "Absence is not error", "Create or return"], ["Stale", "△ Age + last known", "Old truth is marked", "Refresh or proceed knowingly"], ["Conflict", "◆ Side-by-side change", "Draft and canon preserved", "Review, merge or cancel"], ["Recovery", "↺ Cause + retained work", "Draft survives failure", "Retry or restore"], ["Unavailable", "■ Reason + boundary", "No invented permission", "Choose a valid alternative"]].map((row) => <div className="matrix-row" role="row" key={row[0]}>{row.map((cell, index) => <span role="cell" key={cell} className={index === 0 ? "matrix-state" : ""}>{cell}</span>)}</div>)}</div>
          </section>

          <section id="access" className="library-section access-section" aria-labelledby="access-title">
            <div className="section-heading"><div><span className="eyebrow">ACCESS IS CORE CONTROL</span><h2 id="access-title">Change the presentation, never the player’s permission</h2><p>These live switches demonstrate library-wide accessibility variants.</p></div></div>
            <div className="access-grid"><div className="access-controls"><label><span><strong>Compact density</strong><small>Preserves every capability</small></span><input type="checkbox" checked={density === "compact"} onChange={(event) => setDensity(event.target.checked ? "compact" : "comfortable")} /></label><label><span><strong>High contrast</strong><small>Strengthens edges and focus</small></span><input type="checkbox" checked={contrast} onChange={(event) => setContrast(event.target.checked)} /></label><label><span><strong>115% text</strong><small>Reflows without clipping</small></span><input type="checkbox" checked={largeText} onChange={(event) => setLargeText(event.target.checked)} /></label><label><span><strong>Reduce motion</strong><small>Uses final-state substitutes</small></span><input type="checkbox" checked={reduceMotion} onChange={(event) => setReduceMotion(event.target.checked)} /></label></div><div className="alternate-tray"><span className="eyebrow">ALTERNATE INPUT TRAY</span><h3>Build intent without free typing</h3><p>Choose one goal and one method. This tray supplements the Intent Dock; it does not reduce available actions.</p><div><button onClick={() => setGoal("Reach the archive")}>Goal · Reach archive</button><button onClick={() => setGoal("Learn who changed the seal")}>Goal · Learn about seal</button><button onClick={() => setMethod("Move quietly along the east ledge")}>Method · Move quietly</button><button onClick={() => setMethod("Work with Nyra")}>Method · Ask for help</button></div></div></div>
            <div className="access-promises"><div><strong>200%</strong><span>Zoom-ready reflow</span></div><div><strong>2 px + 3</strong><span>Focus width + offset</span></div><div><strong>0</strong><span>Color-only meanings</span></div><div><strong>40 / 40</strong><span>Keyboard-operable specs</span></div></div>
          </section>
        </main>
      </div>
      <footer><span>MYTHIC RPG · UI-01 COMPONENT LIBRARY · APPROVAL CANDIDATE</span><span>Planning artifact only · production authorization CLOSED</span></footer>
    </div>
  );
}
