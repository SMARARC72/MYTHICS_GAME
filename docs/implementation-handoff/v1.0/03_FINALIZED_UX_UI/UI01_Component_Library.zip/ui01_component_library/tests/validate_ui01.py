from __future__ import annotations

import json
import re
from pathlib import Path


WORKSPACE = Path("/workspace/scratch/0299d32e143a")
ROOT = WORKSPACE / "outputs/ux_ui_phase7/ui01_component_library"
OUTPUT_ROOT = ROOT.parent


def load_json(name: str):
    return json.loads((ROOT / name).read_text())


manifest = load_json("contract-manifest.json")
components = load_json("component-specification.json")
tokens = load_json("design-tokens.json")
states = load_json("semantic-state-grammar.json")
responsive = load_json("responsive-and-accessibility.json")
artifacts = load_json("artifact-manifest.json")
acceptance = (OUTPUT_ROOT / "Mythic_RPG_UI01_Code_Native_Component_Library_v0.1.md").read_text()

assert manifest["checkpoint"] == "UI-01"
assert manifest["status"] == "approved"
assert manifest["approved_on"] == "2026-08-23"
assert manifest["approved_dependency"]["checkpoint"] == "C4"
assert manifest["approved_dependency"]["status"] == "approved"
assert manifest["implementation_authorized"] is False
assert manifest["product_decisions"]["world_time"] == "Ledger Time"
assert manifest["product_decisions"]["primary_workspace"] == "Adaptive Living World Stage"
assert manifest["product_decisions"]["primary_device"] == "Desktop browser first"
assert "not chatbot skin" in manifest["product_decisions"]["experience_character"]
assert manifest["browser_reference"]["deployment_status"] == "succeeded"
assert manifest["browser_reference"]["url"].startswith("https://")

expected_ids = {f"CMP-{number:02d}" for number in range(1, 41)}
assert len(components) == 40
assert {item["component_id"] for item in components} == expected_ids
assert len({item["component_id"] for item in components}) == 40
required = {
    "component_id", "name", "family", "purpose", "props", "interactive_states",
    "responsive_rule", "accessibility_semantics", "contract_ids", "primary_payloads",
    "fixtures_tests", "authority_owner", "frontend_owner", "trace_status", "ui01_status",
}
for item in components:
    assert required <= item.keys()
    assert all(item[field] not in (None, "", []) for field in required)
    assert item["trace_status"] == "Contract trace complete"
    assert item["ui01_status"] == "approved"
    assert len(item["interactive_states"]) >= 4
    assert all(re.match(r"^(COMMON|RM|CMD|EVF|API|ASYNC|GEN|C2-|C3-)", contract) for contract in item["contract_ids"])

assert manifest["family_counts"] == {"World shell": 7, "Core loop": 13, "Systems": 14, "Accessibility": 6}
assert len(tokens["colors"]) >= 10
assert tokens["geometry"]["control_minimum_px"] >= 40
assert tokens["geometry"]["focus_width_px"] >= 2
assert len(states) == 6
assert {item["state"] for item in states} == {"loading", "empty", "stale", "conflict", "recovery", "unavailable"}
assert len(responsive["breakpoints"]) == 3
assert "200%" in responsive["zoom"]
assert "reduced" in responsive["reduced_motion"].lower() or "final" in responsive["reduced_motion"].lower()
assert len(responsive["landmarks"]) >= 5

page = (ROOT / "browser-reference/app/page.tsx").read_text()
layout = (ROOT / "browser-reference/app/layout.tsx").read_text()
css = (ROOT / "browser-reference/app/globals.css").read_text()
assert "Starter Project" not in page + layout
assert "codex-preview" not in layout
assert "MYTHIC" in page and "INTENT DOCK" in page and "40 component obligations" in page
assert "prefers-reduced-motion" in css and "forced-colors" in css and ":focus-visible" in css
assert "Implementation authorization:** **CLOSED" not in acceptance  # wording uses production boundary
assert "Production implementation authorization:** **CLOSED" in acceptance
assert "CMP-01 through CMP-40" in acceptance

for item in artifacts["artifacts"]:
    target = ROOT / item["path"]
    assert target.exists() and target.stat().st_size == item["bytes"]

report = {
    "checkpoint": "UI-01",
    "status": "approved",
    "component_count": len(components),
    "component_trace_count": sum(bool(item["contract_ids"]) for item in components),
    "documented_prop_count": sum(len(item["props"]) for item in components),
    "interactive_state_count": sum(len(item["interactive_states"]) for item in components),
    "global_semantic_state_count": len(states),
    "artifact_count": len(artifacts["artifacts"]),
    "browser_deployment_status": manifest["browser_reference"]["deployment_status"],
    "implementation_authorization": "CLOSED",
    "failed_gate_count": 0,
}
(ROOT / "validation_report.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
