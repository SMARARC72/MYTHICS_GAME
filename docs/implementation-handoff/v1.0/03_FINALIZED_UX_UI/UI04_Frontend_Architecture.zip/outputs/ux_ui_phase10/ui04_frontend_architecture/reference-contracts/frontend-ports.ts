/**
 * UI-04 type-only reference. This is not production code and imports no vendor.
 * Generated contract types replace the opaque placeholders after authorization.
 */
export type OpaqueContractValue = unknown;
export type ProjectionBasis = Readonly<{ campaignId?: string; viewpointId?: string; contractVersion: string; stateVersion?: string; knowledgeSnapshotId?: string }>;
export interface ProjectionQueryPort { query(operationId: string, basis: ProjectionBasis, input?: OpaqueContractValue): Promise<OpaqueContractValue>; }
export interface CommandPort { send(operationId: string, command: OpaqueContractValue, idempotencyKey: string): Promise<OpaqueContractValue>; }
export interface ReceiptLookupPort { resolve(idempotencyKey: string, commandId?: string): Promise<OpaqueContractValue>; }
export interface OrderedEventPort { connect(basis: ProjectionBasis, cursor?: string): AsyncIterable<OpaqueContractValue>; }
export interface DraftPersistencePort { put(scope: string, version: string, draft: OpaqueContractValue): Promise<void>; get(scope: string): Promise<OpaqueContractValue | undefined>; remove(scope: string): Promise<void>; }
export interface PreferencePort { read(profile: "accessibility" | "content" | "localization"): Promise<OpaqueContractValue>; update(profile: string, command: OpaqueContractValue): Promise<OpaqueContractValue>; }
export interface MediaPort { query(operationId: string, input: OpaqueContractValue): Promise<OpaqueContractValue>; command(operationId: string, input: OpaqueContractValue): Promise<OpaqueContractValue>; }
export interface FocusAnnouncementPort { focus(target: string, fallback: string): void; announce(eventId: string, message: string, priority: "polite" | "assertive"): void; }
