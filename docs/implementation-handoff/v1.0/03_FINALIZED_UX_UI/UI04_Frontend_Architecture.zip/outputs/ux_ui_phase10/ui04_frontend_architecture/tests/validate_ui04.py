from __future__ import annotations

import hashlib
import json
from pathlib import Path


WORKSPACE = Path("/workspace/scratch/0299d32e143a")
ROOT = WORKSPACE / "outputs/ux_ui_phase10/ui04_frontend_architecture"
OUTPUT_ROOT = ROOT.parent


def load(name: str):
    return json.loads((ROOT / name).read_text())


manifest = load("contract-manifest.json")
decisions = load("architecture-decisions.json")
layers = load("frontend-boundaries.json")
routes = load("route-composition.json")
machines = load("state-machines.json")
adapter_contracts = load("adapter-contracts.json")
stores = load("data-ownership.json")
components = load("component-ownership.json")
scenarios = load("scenario-architecture-trace.json")
boundaries = load("error-boundaries-recovery.json")
accessibility = load("accessibility-architecture.json")
assets = load("asset-integration.json")
security = load("security-privacy.json")
performance = load("performance-budgets.json")
observability = load("observability-analytics.json")
tests = load("test-harness-ci.json")
execution = load("execution-plan.json")
repository = load("repository-blueprint.json")
artifacts = load("artifact-manifest.json")
acceptance = (OUTPUT_ROOT / "Mythic_RPG_UI04_Frontend_Architecture_and_Execution_Specification_v0.1.md").read_text()
ports_reference = (ROOT / "reference-contracts/frontend-ports.ts").read_text()

assert manifest["checkpoint"] == "UI-04" and manifest["status"] == "approved"
assert manifest["approved_on"] == "2026-08-23"
assert [item["checkpoint"] for item in manifest["approved_dependencies"]] == ["UI-01", "UI-02", "UI-03"]
assert {item["status"] for item in manifest["approved_dependencies"]} == {"approved"}
assert {item["id"] for item in manifest["prerequisite_specifications"]} == {f"PRE-0{i}" for i in range(1, 7)}
assert manifest["implementation_authorized"] is False
assert manifest["unresolved_product_decision_count"] == 0
assert manifest["product_decisions"]["world_time"] == "Ledger Time"
assert manifest["product_decisions"]["primary_workspace"] == "Adaptive Living World Stage"
assert "Desktop browser first" in manifest["product_decisions"]["primary_device"]
assert "Figma-free" in manifest["product_decisions"]["workflow"]

assert len(decisions) == manifest["counts"]["architecture_decisions"] == 28
assert {item["status"] for item in decisions} == {"approved-lock"}
assert len(layers) == manifest["counts"]["layers"] == 8
assert [item["layer_id"] for item in layers] == [f"L{i}" for i in range(8)]
assert any("optimistic canon" in f'{item["decision"]} {item["rule"]}'.lower() for item in decisions)
assert any("viewpoint" in item["rule"].lower() for item in decisions)

assert len(routes) == manifest["counts"]["routes"] == 14
assert {item["screen_id"] for item in routes} == {f"SCR-{i:02d}" for i in range(1, 15)}
assert len({item["route_pattern"] for item in routes}) == 14
for route in routes:
    assert route["components"] and route["scenarios"] and route["state_machines"]
    assert route["initial_loader_contract"]["validation"].startswith("Runtime-validate")
    assert route["asset_policy"]["core_capability_requires_art"] is False
    assert route["status"] == "approved"

assert len(machines) == manifest["counts"]["state_machines"] == 10
assert len({item["machine_id"] for item in machines}) == 10
assert all(item["states"] and item["events"] and item["invariants"] for item in machines)
intent = next(item for item in machines if item["machine_id"] == "SM-02")
assert {"commit-unknown", "rejected", "refused", "interrupted", "unavailable", "replan", "conflict"} <= set(intent["states"])

ports = adapter_contracts["ports"]
assignments = adapter_contracts["operation_assignments"]
assert len(ports) == manifest["counts"]["ports"] == 16
assert len(assignments) == manifest["counts"]["operations"]
assert len({item["operation_id"] for item in assignments}) == len(assignments)
assert {item["port"] for item in assignments} <= {item["port"] for item in ports}
assert all(item["validation"] == "Generated runtime validator" for item in assignments)

assert len(stores) == manifest["counts"]["stores"] == 8
assert all(item["forbidden"] for item in stores)
assert any("viewpoint" in " ".join(item["forbidden"]).lower() for item in stores)

assert len(components) == manifest["counts"]["components"] == 40
assert {item["component_id"] for item in components} == {f"CMP-{i:02d}" for i in range(1, 41)}
assert all(item["route_owners"] and item["primary_port"] and item["accessibility"] for item in components)
assert {item["status"] for item in components} == {"approved"}

assert len(scenarios) == manifest["counts"]["scenarios"] == 17
assert {item["scenario_id"] for item in scenarios} == {f"SCN-{i:02d}" for i in range(1, 18)}
assert all(item["screens"] and item["machines"] and item["contracts"] for item in scenarios)

assert {item["boundary_id"] for item in boundaries} == {f"EB-{i:02d}" for i in range(1, 7)}
assert "WCAG 2.2 AA" in accessibility["normative_profile"]
assert assets["ui03_dependency"] == {"version":"0.1.0","status":"approved","asset_slots":60,"reference_files":5,"icons":49}
assert assets["no_figma"] is True
assert "Browser is untrusted" in security["trust_boundaries"]
assert len(performance["experience"]) >= 6
assert "player prose" in observability["prohibited"]

assert tests["fixture_count"] == manifest["counts"]["fixtures"] == 127
assert len(tests["gates"]) == manifest["counts"]["ci_gates"] == 15
assert {item["gate_id"] for item in tests["gates"]} == {f"CI-{i:02d}" for i in range(1, 16)}
assert {item["ui04_architecture_evidence"] for item in tests["gates"]} == {"approved architecture mapping"}
assert len(execution) == manifest["counts"]["execution_packets"] == 16
assert [item["packet_id"] for item in execution] == [f"EP-{i:02d}" for i in range(16)]
assert all(item["production_status"].startswith("not started") for item in execution)
seen = set()
for item in execution:
    assert set(item["dependencies"]) <= seen
    seen.add(item["packet_id"])

assert repository["directories"] and "Strict TypeScript" in repository["reference_execution_profile"]
assert "not production code" in ports_reference.lower() and "from \"" not in ports_reference
assert "Clean-session implementation authorization:** **AWAITING EXPLICIT USER AUTHORIZATION" in acceptance
assert "Production deployment and public release:** **CLOSED" in acceptance
assert "Unresolved product decisions | 0" in acceptance
assert "clean-session Codex execution handoff" in acceptance
assert "**Status:** Approved and locked" in acceptance

required_exceptions = {"schema drift", "loading", "empty", "stale", "conflict", "offline", "provider failure"}
architecture_text = " ".join([acceptance, json.dumps(machines), json.dumps(boundaries)]).lower()
assert all(item in architecture_text for item in required_exceptions)

for item in artifacts["artifacts"]:
    target = ROOT / item["path"]
    assert target.exists() and target.stat().st_size == item["bytes"]
    assert hashlib.sha256(target.read_bytes()).hexdigest() == item["sha256"]

report = {
    "checkpoint":"UI-04",
    "status":"approved",
    "route_coverage":"14/14",
    "component_coverage":"40/40",
    "scenario_coverage":"17/17",
    "operation_assignment_count":len(assignments),
    "state_machine_count":len(machines),
    "fixture_count":tests["fixture_count"],
    "ci_gate_coverage":"15/15",
    "execution_packet_count":len(execution),
    "unresolved_product_decision_count":0,
    "implementation_authorization":"AWAITING_EXPLICIT_USER_AUTHORIZATION",
    "production_deployment_and_public_release":"CLOSED",
    "failed_gate_count":0,
}
(ROOT / "validation_report.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
