# UI-04 Architecture Diagrams

These diagrams communicate locked boundaries; they do not select a framework.

## Dependency direction

```mermaid
flowchart LR
  C[L0 Approved contracts + 127 fixtures] --> G[L1 Generated consumers]
  G --> P[L2 Ports/adapters]
  G --> R[L3 Projection repositories]
  P --> R
  R --> W[L4 Workflow coordinators]
  P --> W
  W --> U[L5 UI-01 components]
  R --> S[L6 UI-02 routes]
  U --> S
  S --> V[L7 Verification]
  C --> V
```

## Canonical action

```mermaid
sequenceDiagram
  participant Player
  participant UI as Route + SM-02
  participant Draft as Durable draft/idempotency
  participant Cmd as CommandPort
  participant Engine as Authoritative engine
  participant Events as OrderedEventPort
  Player->>UI: express intent
  UI->>Cmd: interpret / forecast (noncanonical)
  Cmd-->>UI: validated proposal / forecast
  Player->>UI: confirm legal proposal
  UI->>Draft: persist idempotency envelope
  UI->>Cmd: commit
  alt receipt returned
    Cmd-->>UI: authoritative receipt
  else response lost
    UI->>Cmd: resolve status before retry
    Cmd-->>UI: receipt or safe recovery
  end
  Engine->>Events: ordered committed event
  Events-->>UI: reconcile projection basis
  UI-->>Player: world change, cost, unchanged facts, then audit
```

## Knowledge boundary

```mermaid
flowchart TB
  Truth[Canonical + hidden engine truth] --> Projection[PRE-02 viewpoint projection]
  Projection -->|only permitted fields| Validate[Generated runtime validation]
  Validate --> Cache[Viewpoint-keyed projection cache]
  Cache --> Stage[Semantic Stage / screens]
  Truth -. prohibited .-> Cache
  Protected[Protected media audit / rights / prompts] -. server only .-> Media[Public media projection]
  Media --> Stage
```
