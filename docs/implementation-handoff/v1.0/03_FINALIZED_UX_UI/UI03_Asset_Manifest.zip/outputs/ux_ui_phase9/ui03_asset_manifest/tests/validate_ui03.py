from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path


WORKSPACE = Path("/workspace/scratch/0299d32e143a")
ROOT = WORKSPACE / "outputs/ux_ui_phase9/ui03_asset_manifest"
OUTPUT_ROOT = ROOT.parent


def load_json(name: str):
    return json.loads((ROOT / name).read_text())


manifest = load_json("contract-manifest.json")
assets = load_json("asset-register.json")
references = load_json("reference-asset-provenance.json")
icons = load_json("icon-catalog.json")
placements = load_json("screen-asset-placement.json")
briefs = load_json("generation-briefs.json")
technical = load_json("technical-delivery-spec.json")
policy = load_json("provenance-canon-policy.json")
waves = load_json("asset-production-wave-plan.json")
generated_prompt = load_json("generated-reference-prompt.json")
artifacts = load_json("artifact-manifest.json")
acceptance = (OUTPUT_ROOT / "Mythic_RPG_UI03_Image_Icon_Illustration_Asset_Manifest_v0.1.md").read_text()
sprite = (ROOT / "icons/mythic-icon-sprite.svg").read_text()

assert manifest["checkpoint"] == "UI-03"
assert manifest["status"] == "approved"
assert manifest["approved_on"] == "2026-08-23"
assert manifest["approved_dependencies"] == [
    {"checkpoint": "UI-01", "version": "0.1.0", "status": "approved", "approved_on": "2026-08-23"},
    {"checkpoint": "UI-02", "version": "0.1.0", "status": "approved", "approved_on": "2026-08-23"},
]
assert manifest["implementation_authorized"] is False
assert manifest["product_decisions"]["world_time"] == "Ledger Time"
assert manifest["product_decisions"]["primary_workspace"] == "Adaptive Living World Stage"
assert manifest["product_decisions"]["primary_device"] == "Desktop browser first"
assert "Figma-free" in manifest["product_decisions"]["workflow"]
assert manifest["generated_character_portraits"] == 0
assert "Dr. Mara Vance appearance invariant" in manifest["deferred_invariant_decisions"]

asset_ids = [item["id"] for item in assets]
assert len(assets) == manifest["asset_slot_count"] == 60
assert len(asset_ids) == len(set(asset_ids))
assert {item["category"] for item in assets} == {"ambient", "scene", "entity", "object", "event", "comic", "map_texture", "brand", "fallback"}
required_asset_fields = {
    "id", "name", "category", "status", "production_filename_pattern", "screens", "scenarios", "medium",
    "generation_method", "canonical_scope", "knowledge_boundary", "canon_trigger", "meaning_class", "text_policy",
    "master_aspect_ratio", "responsive_delivery", "delivery_formats", "alpha_requirement", "crop_safe_area",
    "alt_text_contract", "semantic_fallback", "motion_rule", "provenance_requirements", "rights_status",
    "review_owner", "implementation_owner", "replacement_rule",
}
for item in assets:
    assert required_asset_fields <= item.keys()
    assert all(item[field] not in (None, "", []) for field in required_asset_fields)
    assert set(item["screens"]) <= {f"SCR-{n:02d}" for n in range(1, 15)}
    assert set(item["scenarios"]) <= {f"SCN-{n:02d}" for n in range(1, 18)}
    assert "No interface labels" in item["text_policy"]
    assert "hidden" in item["knowledge_boundary"].lower()
    assert "never overwrite" in item["replacement_rule"].lower()

assert next(item for item in assets if item["id"] == "VIS-ENT-004")["status"] == "blocked-invariant"
assert all(item["meaning_class"] == "decorative" for item in assets if item["category"] == "map_texture")
assert all("SVG/HTML" in item["semantic_fallback"] for item in assets if item["category"] == "map_texture")

assert len(references) == manifest["reference_file_count"] == 5
for item in references:
    target = ROOT / item["path"]
    assert target.exists() and target.stat().st_size == item["bytes"] and item["bytes"] > 100_000
    assert hashlib.sha256(target.read_bytes()).hexdigest() == item["sha256"]
    assert item["text_baked_in"] is False
    assert item["alt_text"] and item["long_description"]
    assert "review required" in item["rights_status"].lower()
assert {item["status"] for item in references} == {"approved-reference"}
assert next(item for item in references if item["asset_id"] == "VIS-COM-001")["status"] == "approved-reference"

assert len(icons) == manifest["icon_count"] == 49
assert len({item["id"] for item in icons}) == len(icons)
assert len({item["symbol_id"] for item in icons}) == len(icons)
assert {item["category"] for item in icons} == {"destination", "knowledge", "rights", "pressure", "harm", "comic", "state"}
assert "currentColor" in sprite and "<text" not in sprite.lower() and "<script" not in sprite.lower()
assert len(re.findall(r"<symbol id=", sprite)) == len(icons)
for icon in icons:
    assert f'id="{icon["symbol_id"]}"' in sprite
    assert icon["first_use_label_required"] is True
    assert "accessible name" in icon["accessibility"]
    assert icon["status"] == "approved-code-native"

assert len(placements) == manifest["screen_placement_count"] == 14
assert {item["screen_id"] for item in placements} == {f"SCR-{n:02d}" for n in range(1, 15)}
for item in placements:
    assert set(item["asset_ids"]) <= set(asset_ids)
    assert item["fallback_asset_id"] in asset_ids
    assert item["art_required_for_core_capability"] is False
    assert item["status"] == "approved"

covered_scenarios = set().union(*(set(item["scenarios"]) for item in assets))
assert set(manifest["required_scenarios"]) == {"SCN-01", "SCN-06", "SCN-09", "SCN-10", "SCN-14", "SCN-16"}
assert set(manifest["required_scenarios"]) <= covered_scenarios
assert len(briefs) == manifest["generation_brief_count"] == 6
assert all(item["required_inputs"] and item["prompt_template"] and item["negative_constraints"] and item["approval_tests"] for item in briefs)
assert generated_prompt["asset_id"] == "VIS-COM-001" and generated_prompt["status"] == "approved-reference" and "noncanonical" in generated_prompt["prompt"].lower()
assert "no speech bubbles" in generated_prompt["prompt"].lower()

assert technical["vector"]["text_nodes"] == "prohibited"
assert technical["vector"]["semantic_geometry"] == "maps/charts/status/focus/icons remain SVG/HTML"
assert technical["performance_and_failure"]["no_layout_shift"] is True
assert "Figma dependency" in policy["prohibited"]
assert len(waves) == 5 and waves[-1]["name"] == "Release asset QA"

assert "Production implementation authorization:** **CLOSED" in acceptance
assert "UI-04" in acceptance and "60" in acceptance and "49" in acceptance and "14/14" in acceptance
assert "Dr. Mara Vance remains deliberately unillustrated" in acceptance
assert "**Status:** Approved and locked" in acceptance

for item in artifacts["artifacts"]:
    target = ROOT / item["path"]
    assert target.exists() and target.stat().st_size == item["bytes"]
    assert hashlib.sha256(target.read_bytes()).hexdigest() == item["sha256"]

report = {
    "checkpoint": "UI-03",
    "status": "approved",
    "asset_slot_count": len(assets),
    "reference_file_count": len(references),
    "icon_count": len(icons),
    "screen_placement_count": len(placements),
    "required_scenario_coverage": f"{len(manifest['required_scenarios'])}/6",
    "generation_brief_count": len(briefs),
    "generated_character_portrait_count": 0,
    "unresolved_ux_decision_count": 0,
    "implementation_authorization": "CLOSED",
    "failed_gate_count": 0,
}
(ROOT / "validation_report.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
