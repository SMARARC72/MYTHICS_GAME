# Mythic icon sprite

The sprite contains 49 code-native, text-free symbols on a 24×24 canvas with a 1.75px stroke and `currentColor`. It has no Figma dependency.

Embed the sprite once, then reference a symbol with `<svg aria-hidden="true" focusable="false"><use href="#mythic-stage" /></svg>`. Keep a visible label at first use. An icon-only control requires a localized accessible name on the control. Do not give the decorative SVG a competing accessible name. Filled variants are reserved for selected, destructive or immediately due state and never replace text/state semantics.
