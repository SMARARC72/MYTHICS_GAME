from __future__ import annotations

import json
import re
from pathlib import Path


WORKSPACE = Path("/workspace/scratch/0299d32e143a")
ROOT = WORKSPACE / "outputs/ux_ui_phase8/ui02_screen_atlas"
OUTPUT_ROOT = ROOT.parent


def load_json(name: str):
    return json.loads((ROOT / name).read_text())


manifest = load_json("contract-manifest.json")
screens = load_json("screen-specification.json")
states = load_json("state-variant-grammar.json")
scenarios = load_json("scenario-coverage.json")
components = load_json("component-coverage.json")
flow = load_json("interaction-flow.json")
assets = load_json("reference-asset-manifest.json")
artifacts = load_json("artifact-manifest.json")
acceptance = (OUTPUT_ROOT / "Mythic_RPG_UI02_High_Fidelity_Screen_Atlas_v0.1.md").read_text()

assert manifest["checkpoint"] == "UI-02"
assert manifest["status"] == "approved"
assert manifest["approved_on"] == "2026-08-23"
assert manifest["approved_dependency"] == {"checkpoint": "UI-01", "version": "0.1.0", "status": "approved", "approved_on": "2026-08-23"}
assert manifest["implementation_authorized"] is False
assert manifest["product_decisions"]["world_time"] == "Ledger Time"
assert manifest["product_decisions"]["primary_workspace"] == "Adaptive Living World Stage"
assert manifest["product_decisions"]["primary_device"] == "Desktop browser first"
assert manifest["product_decisions"]["workflow"] == "Figma-free code-native browser atlas"
assert manifest["browser_reference"]["deployment_status"] == "succeeded"
assert manifest["browser_reference"]["url"].startswith("https://")

expected_screen_ids = {f"SCR-{number:02d}" for number in range(1, 15)}
expected_scenario_ids = {f"SCN-{number:02d}" for number in range(1, 18)}
expected_component_ids = {f"CMP-{number:02d}" for number in range(1, 41)}
assert len(screens) == 14 and {screen["id"] for screen in screens} == expected_screen_ids
assert len({screen["id"] for screen in screens}) == 14
required = {
    "id", "name", "shortName", "kind", "destination", "route", "playerQuestion", "summary",
    "subviews", "variants", "components", "scenarios", "fixtureLabel", "knowledgeBoundary",
    "keyboardOrder", "liveRegion", "compactRule", "interactionNotes", "status", "headline",
    "primaryAction", "secondaryAction", "facts", "context",
}
for screen in screens:
    assert required <= screen.keys()
    assert all(screen[field] not in (None, "", []) for field in required)
    assert "noncanonical" in screen["fixtureLabel"].lower()
    assert len(screen["keyboardOrder"]) >= 5
    assert len(screen["interactionNotes"]) >= 2
    assert set(screen["components"]) <= expected_component_ids
    assert set(screen["scenarios"]) <= expected_scenario_ids

assert {scenario["id"] for scenario in scenarios} == expected_scenario_ids
assert {component["component_id"] for component in components} == expected_component_ids
assert all(component["screens"] for component in components)
assert all(scenario["status"] == "approved" for scenario in scenarios)
assert all(component["ui02_trace_status"] == "approved" for component in components)
assert set().union(*(set(screen["scenarios"]) for screen in screens)) == expected_scenario_ids
assert set().union(*(set(screen["components"]) for screen in screens)) == expected_component_ids

required_states = {"Ready", "Loading", "Empty", "Stale", "Conflict", "Recovery", "Unavailable", "Offline", "Success", "Mixed", "Failure", "Refusal", "Interruption"}
assert {state["variant"] for state in states if state["category"] == "Public state"} == required_states
required_access = {"Desktop reference", "Compact desktop", "High contrast", "Large text / 200%", "Reduced motion", "Screen reader / alternate input"}
assert {state["variant"] for state in states if state["category"] == "Access presentation"} == required_access
assert all(state["status"] == "approved" for state in states)
assert len(flow["steps"]) == 7
assert [step["name"] for step in flow["steps"]] == ["Perceive", "Inspect", "Declare", "Review", "Commit", "Resolve", "Continue"]

assert len(assets) == 2
assert all(asset["canonical"] is False and asset["generation"] == "AI-generated reference" for asset in assets)
assert {asset["role"] for asset in assets} == {"Stage atmosphere", "Social preview"}

page = (ROOT / "browser-reference/app/page.tsx").read_text()
data = (ROOT / "browser-reference/app/screen-data.ts").read_text()
layout = (ROOT / "browser-reference/app/layout.tsx").read_text()
css = (ROOT / "browser-reference/app/globals.css").read_text()
assert "Starter Project" not in page + data + layout
assert "codex-preview" not in layout
assert "Final Screen Atlas" in page and "Production closed" in page
assert "STATE_OPTIONS" in data and len(re.findall(r'id: "SCR-\d{2}"', data)) == 14
assert "prefers-reduced-motion" in css and "forced-colors" in css and ":focus-visible" in css
assert (ROOT / "browser-reference/public/glass-harbor-archive.png").stat().st_size > 100_000
assert (ROOT / "browser-reference/public/og.png").stat().st_size > 100_000
assert "Production implementation authorization:** **CLOSED" in acceptance
assert "UI-03" in acceptance and "14" in acceptance and "17/17" in acceptance and "40/40" in acceptance

for item in artifacts["artifacts"]:
    target = ROOT / item["path"]
    assert target.exists() and target.stat().st_size == item["bytes"]

report = {
    "checkpoint": "UI-02",
    "status": "approved",
    "screen_family_count": len(screens),
    "public_state_variant_count": len([state for state in states if state["category"] == "Public state"]),
    "access_presentation_count": len([state for state in states if state["category"] == "Access presentation"]),
    "scenario_coverage_count": len(scenarios),
    "component_coverage_count": len(components),
    "artifact_count": len(artifacts["artifacts"]),
    "browser_deployment_status": manifest["browser_reference"]["deployment_status"],
    "unresolved_ux_decision_count": 0,
    "implementation_authorization": "CLOSED",
    "failed_gate_count": 0,
}
(ROOT / "validation_report.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
