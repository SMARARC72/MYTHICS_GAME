import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Mythic RPG UI-02 Screen Atlas",
  description: "Figma-free final screen families, state variants and accessibility contracts for the Mythic Superhero RPG.",
  openGraph: {
    title: "Mythic RPG UI-02 Screen Atlas",
    description: "Final screens · State variants · Accessibility",
    images: [{ url: "/og.png", width: 1200, height: 630, alt: "Mythic RPG UI-02 Screen Atlas" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Mythic RPG UI-02 Screen Atlas",
    description: "Final screens · State variants · Accessibility",
    images: ["/og.png"],
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
