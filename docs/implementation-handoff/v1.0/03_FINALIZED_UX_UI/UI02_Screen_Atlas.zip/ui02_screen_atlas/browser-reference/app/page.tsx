"use client";

import { useMemo, useState } from "react";
import { SCENARIO_LABELS, SCREENS, STATE_OPTIONS, type ScreenSpec, type Tone } from "./screen-data";

type StateOption = (typeof STATE_OPTIONS)[number];

const destinations = ["Stage", "Character", "Company", "Holdings", "World", "Chronicle"];
const destinationGlyphs = ["◈", "◇", "◆", "▣", "⌖", "≡"];

const stateMeta: Record<StateOption, { glyph: string; copy: string; action: string; tone: Tone }> = {
  Ready: { glyph: "●", copy: "Current projection ready", action: "Continue", tone: "known" },
  Loading: { glyph: "◌", copy: "Retrieving viewpoint-safe projection", action: "Leave safely", tone: "neutral" },
  Empty: { glyph: "◇", copy: "No records exist in this scope", action: "Create or return", tone: "neutral" },
  Stale: { glyph: "△", copy: "Last-known facts may have changed", action: "Refresh", tone: "pressure" },
  Conflict: { glyph: "◫", copy: "Local draft and committed canon differ", action: "Review difference", tone: "pressure" },
  Recovery: { glyph: "↶", copy: "Your work is retained; recovery is available", action: "Restore", tone: "agency" },
  Unavailable: { glyph: "□", copy: "This action is unavailable for the stated reason", action: "Choose alternative", tone: "uncertain" },
  Offline: { glyph: "⊘", copy: "Offline; confirmed records and local drafts remain", action: "Work locally", tone: "pressure" },
  Success: { glyph: "✓", copy: "Committed result confirmed", action: "Continue", tone: "known" },
  Mixed: { glyph: "◒", copy: "The goal advanced with a material cost", action: "Inspect causes", tone: "uncertain" },
  Failure: { glyph: "×", copy: "The attempt failed; unchanged facts remain explicit", action: "Revise intent", tone: "pressure" },
  Refusal: { glyph: "✦", copy: "An autonomous actor declined and named a boundary", action: "Revise request", tone: "uncertain" },
  Interruption: { glyph: "!", copy: "A blocking change opened a decision window", action: "Respond", tone: "pressure" },
};

function Tag({ children, tone = "neutral" }: { children: React.ReactNode; tone?: Tone }) {
  return <span className={`tag tone-${tone}`}>{children}</span>;
}

function FactCard({ label, value, tone }: { label: string; value: string; tone: Tone }) {
  return <article className={`fact-card tone-${tone}`}><span>{label}</span><strong>{value}</strong></article>;
}

function StatusNotice({ state }: { state: StateOption }) {
  const meta = stateMeta[state];
  return (
    <div className={`state-notice tone-${meta.tone}`} role={state === "Interruption" || state === "Recovery" ? "alert" : "status"}>
      <span className="state-glyph" aria-hidden="true">{meta.glyph}</span>
      <div><strong>{state}</strong><span>{meta.copy}</span></div>
      <button type="button">{meta.action}</button>
    </div>
  );
}

function StageSurface({ screen, state }: { screen: ScreenSpec; state: StateOption }) {
  const isDanger = screen.kind === "danger";
  const isResolution = screen.kind === "resolution";
  return (
    <div className="stage-surface">
      <section className={`scene-frame ${isDanger ? "danger-scene" : ""}`} aria-label="Scene frame">
        <img src="/glass-harbor-archive.png" alt="Noncanonical reference art of a rain-dark flooded archival district" />
        <div className="scene-shade" />
        <div className="fixture-flag">REFERENCE FIXTURE · NONCANONICAL</div>
        <div className="scene-copy">
          <p>{isDanger ? "IMMEDIATE DANGER" : isResolution ? "ACTION REVIEW" : "DROWNED ARCHIVE · THRESHOLD"}</p>
          <h3>{screen.headline}</h3>
          <div className="marker-row">
            {screen.facts.map((fact) => <Tag key={fact.label} tone={fact.tone}>{fact.label} · {fact.value}</Tag>)}
          </div>
        </div>
      </section>
      <div className="stage-lower">
        <article className="speech-card">
          <span className="eyebrow">EXACT SPEECH · CURATOR ILYA</span>
          <blockquote>“The archive does not open. It remembers who asked.”</blockquote>
          <span className="muted">Heard clearly · no private motive inferred</span>
        </article>
        <aside className="lens-card">
          <div className="panel-heading"><span>CONTEXT LENS</span><Tag tone="uncertain">Inferred</Tag></div>
          <strong>Floodgate sigil</strong>
          <p>Its lower arc matches the resin mark in the Salt Ledger. The match is plausible, not confirmed.</p>
          <button type="button" className="text-button">Pin to intent →</button>
        </aside>
      </div>
      <section className="intent-dock" aria-label="Intent Dock">
        <div className="intent-field"><span>GOAL</span><strong>{isDanger ? "Get Mara and Ilya clear" : "Reach the sealed archive"}</strong></div>
        <div className="intent-field"><span>METHOD</span><strong>{isResolution ? "Follow the doorway's reflection" : "Trace the sigil while speaking Ilya's name"}</strong></div>
        <button type="button" className="primary-action">{screen.primaryAction}</button>
      </section>
      {state === "Loading" && <div className="loading-scrim" aria-label="Loading projection"><span /><span /><span /></div>}
    </div>
  );
}

function RecordSurface({ screen }: { screen: ScreenSpec }) {
  const library = screen.kind === "library";
  const recovery = screen.kind === "recovery";
  const settings = screen.kind === "settings";
  return (
    <div className="record-surface">
      <div className="record-hero">
        <div><span className="eyebrow">{screen.status}</span><h3>{screen.headline}</h3><p>{screen.summary}</p></div>
        <div className="hero-actions"><button type="button" className="primary-action">{screen.primaryAction}</button><button type="button" className="secondary-action">{screen.secondaryAction}</button></div>
      </div>
      <div className="fact-grid">{screen.facts.map((fact) => <FactCard key={fact.label} {...fact} />)}</div>
      <div className="record-columns">
        <section className="ledger-panel">
          <div className="panel-heading"><span>{library ? "CAMPAIGN SHELF" : recovery ? "SAVED LAYERS" : settings ? "CURRENT PROFILE" : "PRIMARY RECORD"}</span><Tag tone="known">Recorded</Tag></div>
          {screen.context.map((item, index) => (
            <button type="button" className={`record-row ${index === 0 ? "selected" : ""}`} key={item}>
              <span className="record-index">0{index + 1}</span><span><strong>{item}</strong><small>{index === 0 ? "Selected · inspectable" : "Available in this viewpoint"}</small></span><span aria-hidden="true">›</span>
            </button>
          ))}
        </section>
        <aside className="detail-panel">
          <div className="panel-heading"><span>{settings ? "PRESENTATION PREVIEW" : "INSPECTED DETAIL"}</span><Tag tone="agency">Player-safe</Tag></div>
          <h4>{screen.playerQuestion}</h4><p>{screen.knowledgeBoundary}</p>
          <div className="mini-timeline"><span className="done">Confirmed</span><span className="active">Current</span><span>Next</span></div>
        </aside>
      </div>
    </div>
  );
}

function SystemSurface({ screen }: { screen: ScreenSpec }) {
  const isWorld = screen.kind === "travel" || screen.kind === "investigation";
  const isChronicle = screen.kind === "chronicle";
  return (
    <div className="system-surface">
      <div className="system-intro"><span className="eyebrow">{screen.status}</span><h3>{screen.headline}</h3><p>{screen.summary}</p></div>
      <div className={`system-visual ${isWorld ? "map-visual" : isChronicle ? "timeline-visual" : "profile-visual"}`}>
        <div className="visual-grid" aria-hidden="true" />
        {isWorld && <><span className="map-node node-a">LOWER BREAKWATER</span><span className="map-node node-b">BELL CAUSEWAY</span><span className="map-node node-c">DROWNED ARCHIVE</span><svg viewBox="0 0 600 260" aria-hidden="true"><path d="M80 188 C160 60 260 225 360 120 S500 65 548 42" /></svg></>}
        {isChronicle && <div className="timeline-stack">{["Receipt 7K2 · mixed outcome", "Archive threshold recorded", "Comic source lock created", "Issue 3 · producing"].map((item, i) => <div key={item}><span>{i + 1}</span><strong>{item}</strong><small>{i < 2 ? "Committed canon" : "Background media"}</small></div>)}</div>}
        {!isWorld && !isChronicle && <div className="profile-ring"><span>18</span><small>BUILD POINTS</small></div>}
      </div>
      <div className="fact-grid">{screen.facts.map((fact) => <FactCard key={fact.label} {...fact} />)}</div>
      <div className="action-footer"><span>{screen.context.join(" · ")}</span><button type="button" className="primary-action">{screen.primaryAction}</button></div>
    </div>
  );
}

function ActiveSurface({ screen, state }: { screen: ScreenSpec; state: StateOption }) {
  if (["stage", "resolution", "danger"].includes(screen.kind)) return <StageSurface screen={screen} state={state} />;
  if (["library", "recovery", "settings"].includes(screen.kind)) return <RecordSurface screen={screen} />;
  return <SystemSurface screen={screen} />;
}

function GameFrame({ screen, state, compact }: { screen: ScreenSpec; state: StateOption; compact: boolean }) {
  const [activeSubview, setActiveSubview] = useState(screen.subviews[0]);
  return (
    <div className={`game-frame ${compact ? "compact-frame" : ""}`} key={`${screen.id}-${compact}`}>
      <header className="world-strip">
        <div className="mythic-mark"><span>MYTHIC</span><small>GLASS HARBOR</small></div>
        <div className="world-fact"><span>LEDGER TIME</span><strong>Day 18 · Watch 2</strong></div>
        <div className="world-fact"><span>VIEWPOINT</span><strong>Mara Vale</strong></div>
        <div className="world-fact pressure"><span>PRESSURE</span><strong>Tidemark rising</strong></div>
        <button type="button" className="world-menu" aria-label="Open campaign menu">•••</button>
      </header>
      <div className="game-body">
        <nav className="campaign-rail" aria-label="Campaign destinations">
          {destinations.map((item, index) => <button type="button" key={item} className={item === screen.destination ? "active" : ""} title={item}><span>{destinationGlyphs[index]}</span><small>{item}</small></button>)}
        </nav>
        <main className="game-main">
          <header className="surface-header"><div><span className="eyebrow">{screen.destination.toUpperCase()} · {screen.id}</span><h2>{screen.name}</h2></div><Tag tone="known">{screen.fixtureLabel}</Tag></header>
          <nav className="subview-tabs" aria-label={`${screen.name} sections`}>{screen.subviews.map((subview) => <button type="button" key={subview} className={activeSubview === subview ? "active" : ""} onClick={() => setActiveSubview(subview)}>{subview}</button>)}</nav>
          {state !== "Ready" && <StatusNotice state={state} />}
          <ActiveSurface screen={screen} state={state} />
        </main>
      </div>
      <footer className="chronicle-ribbon"><span>CHRONICLE</span><strong>Latest · Archive threshold recorded</strong><small>Canon receipt 7K2</small><button type="button">Open record</button></footer>
    </div>
  );
}

export default function Home() {
  const [selectedId, setSelectedId] = useState("SCR-04");
  const [state, setState] = useState<StateOption>("Ready");
  const [compact, setCompact] = useState(false);
  const [highContrast, setHighContrast] = useState(false);
  const [largeText, setLargeText] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [query, setQuery] = useState("");
  const [panel, setPanel] = useState<"contract" | "coverage">("contract");

  const selected = SCREENS.find((screen) => screen.id === selectedId) ?? SCREENS[0];
  const visibleScreens = useMemo(() => {
    const term = query.trim().toLowerCase();
    return term ? SCREENS.filter((screen) => `${screen.id} ${screen.name} ${screen.destination}`.toLowerCase().includes(term)) : SCREENS;
  }, [query]);
  const scenarioCount = new Set(SCREENS.flatMap((screen) => screen.scenarios)).size;
  const componentCount = new Set(SCREENS.flatMap((screen) => screen.components)).size;

  return (
    <main className={`atlas ${highContrast ? "high-contrast" : ""} ${largeText ? "large-text" : ""} ${reducedMotion ? "reduced-motion" : ""}`}>
      <header className="atlas-topbar">
        <div><span className="kicker">MYTHIC RPG · UI-02 CANDIDATE · FIGMA-FREE</span><h1>Final Screen Atlas</h1></div>
        <div className="coverage-summary" aria-label="Coverage summary"><span><strong>14</strong> screen families</span><span><strong>{componentCount}</strong> components</span><span><strong>{scenarioCount}</strong> scenarios</span><Tag tone="pressure">Production closed</Tag></div>
      </header>

      <section className="atlas-toolbar" aria-label="Screen atlas controls">
        <div className="segmented"><button type="button" className={!compact ? "active" : ""} onClick={() => setCompact(false)}>Desktop · 1440×900</button><button type="button" className={compact ? "active" : ""} onClick={() => setCompact(true)}>Compact · 1280×720</button></div>
        <label className="select-control"><span>State variant</span><select value={state} onChange={(event) => setState(event.target.value as StateOption)}>{STATE_OPTIONS.map((option) => <option key={option}>{option}</option>)}</select></label>
        <div className="toggle-cluster"><button type="button" aria-pressed={largeText} className={largeText ? "active" : ""} onClick={() => setLargeText(!largeText)}>115% text</button><button type="button" aria-pressed={highContrast} className={highContrast ? "active" : ""} onClick={() => setHighContrast(!highContrast)}>High contrast</button><button type="button" aria-pressed={reducedMotion} className={reducedMotion ? "active" : ""} onClick={() => setReducedMotion(!reducedMotion)}>Reduced motion</button></div>
      </section>

      <section className="atlas-workspace">
        <aside className="screen-index">
          <div className="index-heading"><span>SCREEN FAMILIES</span><strong>{visibleScreens.length} / 14</strong></div>
          <label className="search-field"><span className="sr-only">Filter screens</span><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Filter screens…" /></label>
          <div className="screen-list">{visibleScreens.map((screen) => <button type="button" key={screen.id} className={selectedId === screen.id ? "active" : ""} onClick={() => { setSelectedId(screen.id); setState("Ready"); }}><span>{screen.id}</span><strong>{screen.shortName}</strong><small>{screen.destination} · {screen.variants.length} states</small></button>)}</div>
        </aside>

        <section className="canvas-region" aria-label="Selected high-fidelity screen">
          <div className="canvas-header"><div><span className="eyebrow">LIVE REFERENCE CANVAS</span><strong>{selected.route}</strong></div><div className="canvas-key"><span>● Ready</span><span>△ State caution</span><span>◈ Player agency</span></div></div>
          <div className={`viewport-shell ${compact ? "compact" : "desktop"}`}>
            <div className="viewport-label"><span>{compact ? "COMPACT CAPABILITY VARIANT" : "DESKTOP REFERENCE"}</span><strong>{compact ? "1280 × 720" : "1440 × 900"}</strong></div>
            <GameFrame screen={selected} state={state} compact={compact} />
          </div>
          <p className="art-disclosure">Atmospheric artwork is noncanonical reference imagery. All game facts are deterministic fixtures for UX validation.</p>
        </section>

        <aside className="variant-inspector">
          <div className="inspector-tabs"><button type="button" className={panel === "contract" ? "active" : ""} onClick={() => setPanel("contract")}>Contract</button><button type="button" className={panel === "coverage" ? "active" : ""} onClick={() => setPanel("coverage")}>Coverage</button></div>
          {panel === "contract" ? <>
            <section><span className="eyebrow">PLAYER QUESTION</span><h2>{selected.playerQuestion}</h2><p>{selected.summary}</p></section>
            <section><span className="eyebrow">KNOWLEDGE BOUNDARY</span><p>{selected.knowledgeBoundary}</p></section>
            <section><span className="eyebrow">KEYBOARD ORDER</span><ol>{selected.keyboardOrder.map((item) => <li key={item}>{item}</li>)}</ol></section>
            <section><span className="eyebrow">LIVE REGION</span><p>{selected.liveRegion}</p></section>
            <section><span className="eyebrow">COMPACT RULE</span><p>{selected.compactRule}</p></section>
          </> : <>
            <section><span className="eyebrow">STATE SET</span><div className="tag-cloud">{selected.variants.map((variant) => <Tag key={variant} tone={variant === "Ready" || variant === "Success" ? "known" : variant === "Conflict" || variant === "Interruption" ? "pressure" : "neutral"}>{variant}</Tag>)}</div></section>
            <section><span className="eyebrow">SCENARIOS</span><div className="tag-cloud">{selected.scenarios.map((scenario) => <Tag key={scenario} tone="agency">{scenario}</Tag>)}</div></section>
            <section><span className="eyebrow">COMPONENTS</span><div className="component-cloud">{selected.components.map((component) => <span key={component}>{component}</span>)}</div></section>
            <section><span className="eyebrow">INTERACTION NOTES</span><ul>{selected.interactionNotes.map((note) => <li key={note}>{note}</li>)}</ul></section>
          </>}
        </aside>
      </section>

      <section className="flow-band" aria-labelledby="flow-title">
        <div><span className="kicker">CORE PLAY LOOP</span><h2 id="flow-title">Perceive → inspect → declare → review → commit → resolve → continue</h2></div>
        <div className="flow-steps">{["Perceive", "Inspect", "Declare", "Review", "Commit", "Resolve", "Continue"].map((step, index) => <span key={step}><small>0{index + 1}</small>{step}</span>)}</div>
      </section>

      <section className="inventory-section" aria-labelledby="inventory-title">
        <div className="section-heading"><div><span className="kicker">SCREEN INVENTORY</span><h2 id="inventory-title">Fourteen final families, one coherent shell</h2></div><p>Every family defines deterministic fixtures, a viewpoint-safe boundary, keyboard order, live-region behavior and compact recomposition.</p></div>
        <div className="inventory-table" role="table" aria-label="UI-02 screen inventory">
          <div className="inventory-row inventory-head" role="row"><span>ID / SCREEN</span><span>DESTINATION</span><span>BASELINE STATES</span><span>SCENARIOS</span></div>
          {SCREENS.map((screen) => <button type="button" role="row" className="inventory-row" key={screen.id} onClick={() => { setSelectedId(screen.id); document.querySelector(".atlas-workspace")?.scrollIntoView({ behavior: reducedMotion ? "auto" : "smooth" }); }}><span><strong>{screen.id}</strong>{screen.name}</span><span>{screen.destination}</span><span>{screen.variants.slice(0, 4).join(" · ")}{screen.variants.length > 4 ? ` +${screen.variants.length - 4}` : ""}</span><span>{screen.scenarios.join(" · ")}</span></button>)}
        </div>
      </section>

      <section className="coverage-section" aria-labelledby="coverage-title">
        <div className="section-heading"><div><span className="kicker">VALIDATION MAP</span><h2 id="coverage-title">Seventeen scenario walkthroughs</h2></div><p>Coverage proves the screen set can express required player outcomes. It does not claim live-engine, usability or release validation.</p></div>
        <div className="scenario-grid">{Object.entries(SCENARIO_LABELS).map(([id, label]) => { const screens = SCREENS.filter((screen) => screen.scenarios.includes(id)).map((screen) => screen.id); return <article key={id}><div><Tag tone="known">{id}</Tag><strong>{label}</strong></div><p>{screens.join(" · ")}</p></article>; })}</div>
      </section>

      <footer className="atlas-footer"><div><strong>UI-02 candidate boundary</strong><p>Approval will lock these screen families, state variants and interaction notes and authorize UI-03 asset-manifest work. Production frontend construction remains closed.</p></div><Tag tone="pressure">Awaiting product-owner approval</Tag></footer>
    </main>
  );
}

